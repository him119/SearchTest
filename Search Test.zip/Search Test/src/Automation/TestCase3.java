/**
 * 
 */
package Automation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author hsheladia
 *
 */
public class TestCase3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\hsheladia\\Downloads\\geckodriver-v0.29.0-win64\\geckodriver.exe"); 
		WebDriver driver = new FirefoxDriver();
		
        driver.get("https://www.google.com/");
       
        //Negative Test cases 
        //Test Case 3 - Verify that clicking the search result will lead to the corresponding web page
        
        WebElement elem = driver.findElement(By.name("q"));//finding the web element using name
        elem.sendKeys(new String[]{"duck"});
        elem.submit();  
        
        // wait until the google page shows the result
       WebDriverWait w = new WebDriverWait(driver, 5);
       w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul")));
       elem.submit();
       
       driver.findElement(By.xpath(".//*[@id='rso']/li[3]/div/h3/a")).click();
       
        
	}

}
