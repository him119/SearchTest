/**
 * 
 */
package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author hsheladia
 *
 */
public class TestCase2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\hsheladia\\Downloads\\geckodriver-v0.29.0-win64\\geckodriver.exe"); 
		WebDriver driver = new FirefoxDriver();
		
        driver.get("https://www.google.com/");
       
        //Negative Test cases 
        //Test Case 2- Verify that incorrect keywords � 'duckck' should lead to �Did you mean: duck � response
        
        WebElement elem = driver.findElement(By.name("q"));//finding the web element using name
        elem.sendKeys(new String[]{"duckck"});
        elem.submit();      
       
        
	}

}
