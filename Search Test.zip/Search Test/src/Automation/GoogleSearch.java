package Automation;

import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class GoogleSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.gecko.driver","C:\\Users\\hsheladia\\Downloads\\geckodriver-v0.29.0-win64\\geckodriver.exe"); 
		WebDriver driver = new FirefoxDriver();
		
        driver.get("https://www.google.com/");
        
        //Test Case 1 - Happy Path - search 'Duck' : Verify that the response fetched for 'Duck' is correct and related to the keyword
        //Verify that the response are sorted by relevance in descending order i.e. most relevant result for the duck are displayed on top
        //Verify that the link title, URL and description have the keyword highlighted in the response
        
        WebElement elem = driver.findElement(By.name("q"));//finding the web element using name
        elem.sendKeys(new String[]{"duck"});
        elem.submit();        

	}

}
